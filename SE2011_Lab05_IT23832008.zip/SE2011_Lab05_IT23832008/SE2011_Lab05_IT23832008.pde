
int state = 0; // 0=start, 1=play, 2=end
int startTime;
int duration = 30; 
int score = 0;

float px = 350, py = 175;
float step = 6;
float pr = 20;

float ox, oy;
float oxs, oys;
float or = 15;

float hx, hy;
float ease = 0.10;

boolean trails = false;

void setup() {
  size(700, 350);
  resetOrb();
  hx = px;
  hy = py;
}

void draw() {

  if (!trails) {
    background(245);
  } else {
    noStroke();
    fill(245, 35);
    rect(0, 0, width, height);
  }
  
  if (state == 0) {
    textAlign(CENTER, CENTER);
    fill(0);
    textSize(35);
    text("CATCH THE ORB",350, 130);
    textSize(18);
    text("Press ENTER to Start",350, 180);
    textSize(15);
    text("Use arrow keys to move", 350, 230);
    text("Press T to toggle trails", 350,  250);
  }

  if (state == 1) {
    int elapsed = (millis() - startTime) / 1000;
    int left = duration - elapsed;
    
    if (left <= 0) {
      state = 2; 
    }

    if (keyPressed) {
      if (keyCode == RIGHT) px += step;
      if (keyCode == LEFT) px -= step;
      if (keyCode == DOWN) py += step;
      if (keyCode == UP) py -= step;
    }

    px = constrain(px, pr, width - pr);
    py = constrain(py, pr, height - pr);

    ox += oxs;
    oy += oys;

    if (ox > width - or || ox < or) oxs *= -1;
    if (oy > height - or || oy < or) oys *= -1;
    
    hx = hx + (px - hx) * ease;
    hy = hy + (py - hy) * ease;
    
    float distance = dist(px, py, ox, oy);
    if (distance < pr + or) {
      score++;
      resetOrb();
      oxs *= 1.1;
      oys *= 1.1;
    }
    
    fill(255, 100, 100);
    noStroke();
    ellipse(ox, oy, or*2, or*2);
    
    fill(60, 120, 200);
    ellipse(px, py, pr*2, pr*2);  //p
    
    fill(80, 200, 120);
    ellipse(hx, hy, 16, 16);   //h

    textAlign(LEFT, TOP);
    fill(0);
    textSize(18);
    text("Score: " + score, 20, 20);
    text("Time: " + left, 20, 45);
    textSize(14);
    text("Trails: " + (trails ? "ON" : "OFF") + " (T)", 20, 70);
  }
  if (state == 2) {
    textAlign(CENTER, CENTER);
    fill(0);
    textSize(32);
    text("GAME OVER!", 350, 130);
    textSize(24);
    text("Final Score: " + score, 350, 180);
    textSize(18);
    text("Press R to Restart", 350, 220);
  }
}

void keyPressed() {
  if (state == 0 && keyCode == ENTER) {
    state = 1;
    startTime = millis();
    score = 0;
    px = 350;
    py = 175;
    hx = px;
    hy = py;
    resetOrb();
  }
  if (state == 2 && (key == 'r' || key == 'R')) {
    state = 0;
  }
  if (key == 't' || key == 'T') {
    trails = !trails;
  }
}

void resetOrb() {
  ox = random(or + 20, width - or - 20);
  oy = random(or + 20, height - or - 20);
  oxs = random(2, 5) * (random(1) > 0.5 ? 1 : -1);
  oys = random(2, 5) * (random(1) > 0.5 ? 1 : -1);
}
